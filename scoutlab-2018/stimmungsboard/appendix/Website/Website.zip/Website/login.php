<!doctype html>
<?php
		session_start();
		$_SESSION["login"] = false;
      include "user/config.php";
?>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="css/normalize.min.css">
        <link rel="stylesheet" href="css/main.css">

        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>

        <div class="header-container">
            <header class="wrapper clearfix">
                <h1 class="title">Stimmungsboard</h1>
				<nav>
                    <ul>
                        <li><a href="#">Login</a></li>
                        <li><a href="regi.php">Registrieren</a></li>
                    </ul>
                </nav>
            </header>
        </div>

        <div class="main-container">
            <div class="main wrapper clearfix">

                <article>
                    <header>
                        <h1>Login</h1>
                        <p>
							<form action="#" method="post">
								<table>
									<tr>
										<td>E-Mail </td>
										<td><input type="email" name="email" /></td>
									</tr>
									<tr>
										<td>Passwort </td>
										<td><input type="password" name="pwd" /></td>
									</tr>
									<tr>
										<td></td>
										<td><input type="submit" value="Einloggen" /></td>
									</tr>
								</table>
							</form>
							<?php
								if(!empty($_POST["email"]) && !empty($_POST["pwd"])) {
									$email = inputsaver($_POST["email"]);
									$pwd  = inputsaver($_POST["pwd"]) ;
									  
									$pwd = genHash($pwd);
									  
									$conn = new mysqli($s_name, $s_username, $s_password, $s_dbname);
													
									if($conn->connect_error) {
									   die("Es gab ein Problem mit der Datenbankverbindung. Bitte versuche es später erneut.");
									}
									$sql = $conn->prepare("SELECT ID FROM users WHERE email=? AND password=?");
									$sql->bind_param("ss", $email, $pwd);
									$sql->execute();
									$sql->bind_result($res_ID, $res_email);
									//echo $sql->fetch();
									if($sql->fetch() !=1 ) {
										echo "<b style='color: red;'>FALSCHES PASSWORT ODER FALSCHER BENUTZERNAME<br />VERSUCHE ES ERNEUT!</b>";
									} else {
										$_SESSION["ID"]       = $res_ID;
										$_SESSION["login"]    = true;
										echo "<h1>Du wurdest erfoglreich angemeldet!</h1>";
										header("location: index.php");
									}
													
									$sql->close();
								}
							?>
						</p>
                    </header>
                </article>

            </div> <!-- #main -->
        </div> <!-- #main-container -->

        <div class="footer-container">
            <footer class="wrapper">
                <h3>Ein Projekt von PiDi, Spike und Julius im Rahmen des Scoutlabs 2018</h3>
            </footer>
        </div>

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.js"><\/script>')</script>

        <script src="js/main.js"></script>
    </body>
</html>
