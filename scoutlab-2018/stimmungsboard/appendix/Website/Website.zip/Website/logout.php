<?php
  session_start();
  
  function delete_Session() {
		session_unset();
		session_destroy();
	}
  
  delete_Session();
  header("location: login.php");
?>