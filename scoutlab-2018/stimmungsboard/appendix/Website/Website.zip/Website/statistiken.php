<?php require("user/header.php"); ?>
		<div class="main-container">
            <div class="main wrapper clearfix">
                <article>
                    <header>
                        <h1>Statistiken</h1>
                        <p>
							Hier findest du alle deine Statistiken.
						</p>
                    </header>
                    <section>
                        <h2>Bewertung von
							<form action="statistiken.php" method="get">
							<select name="datum">
							<?php
								$conn = new mysqli($s_name, $s_username, $s_password, $s_dbname);
						
								if($conn->connect_error) {
								   die("Es gab ein Problem mit der Datenbankverbindung. Bitte versuche es später erneut.");
								}
								$sql = $conn->prepare("SELECT ID, Datum FROM stimmungsboard");
								$sql->execute();
								$sql->bind_result($res_ID, $res_datum);
								while($sql->fetch()) {
									echo "<option value='$res_ID'>$res_datum</option>";
								}
							?>
							</select>
							<input type="submit" value="Senden" />
							</form>
							<?php
								if(!empty($_GET["datum"])) {
									$datum = htmlspecialchars(stripcslashes(trim($_GET["datum"])));
									
									$conn = new mysqli($s_name, $s_username, $s_password, $s_dbname);
													
									if($conn->connect_error) {
										die("Es gab ein Problem mit der Datenbankverbindung. Bitte versuche es später erneut.");
									}
									$sql = $conn->prepare("SELECT Datum, Gut, Mittel, Schlecht, Schnitt FROM stimmungsboard WHERE ID=?");
									$sql->bind_param("s", $datum);
									$sql->execute();
									$sql->bind_result($res_datum, $res_gut, $res_mittel, $res_schlecht, $res_schnitt);
									
									if($sql->fetch()) {
										echo "
											<script type='text/javascript'>
												google.charts.load('current', {'packages':['corechart']});
												google.charts.setOnLoadCallback(drawChart);
												function drawChart() {
													var data = google.visualization.arrayToDataTable([
														['Art', 'Stimmen'],
														['Gut',     $res_gut],
														['Mittel',      $res_mittel],
														['Schlecht',  $res_schlecht]]);
													var options = {
													  title:  \"Die Stimmung am \"+\"$res_datum\"
													};

													var chart = new google.visualization.PieChart(document.getElementById('chart1'));

													chart.draw(data, options);
												}
												drawChart();
											</script>";
									}
								}
							?>
						</h2>
                        <p id="chart1"></p>
                    </section>
                    <section>
                        <h2>Stimmung im Verlauf der Zeit <button onClick="javascript:location.reload();">Aktualisieren</button></h2>
						<?php
							$conn = new mysqli($s_name, $s_username, $s_password, $s_dbname);
													
							if($conn->connect_error) {
								die("Es gab ein Problem mit der Datenbankverbindung. Bitte versuche es später erneut.");
							}
							$sql = $conn->prepare("SELECT Datum, Schnitt FROM stimmungsboard");
							$sql->execute();
							$sql->bind_result($res_datum, $res_schnitt);
							
							$data = "[['Tag', 'Durchschnitt'],";
							
							while($sql->fetch()) {
								$data = $data . "['$res_datum',  $res_schnitt],";
								//echo $res_datum . " " . $res_schnitt;
							}
							
							$data[strlen($data)-1]="]";
							
							echo "
								<script>
									google.charts.load('current', {'packages':['corechart']});
									google.charts.setOnLoadCallback(drawChart);

									function drawChart() {
										var data = google.visualization.arrayToDataTable($data);

										var options = {
											title: 'Stimmung im Lauf der Zeit',
											curveType: 'function',
											legend: { position: 'bottom' }
										};

										var chart = new google.visualization.LineChart(document.getElementById('chart2'));

										chart.draw(data, options);
									}
								</script>";
						?>
                        <p id="chart2"></p>
                    </section>
                </article>
            </div> <!-- #main -->
        </div> <!-- #main-container -->
<?php  require("user/footer.php"); ?>