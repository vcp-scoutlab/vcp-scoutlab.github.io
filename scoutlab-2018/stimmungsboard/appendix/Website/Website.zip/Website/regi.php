<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="css/normalize.min.css">
        <link rel="stylesheet" href="css/main.css">

        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>

        <div class="header-container">
            <header class="wrapper clearfix">
                <h1 class="title">Stimmungsboard</h1>
				<nav>
                    <ul>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="regi.php">Registrieren</a></li>
                    </ul>
                </nav>
            </header>
        </div>

        <div class="main-container">
            <div class="main wrapper clearfix">

                <article>
                    <header>
                        <h1>Registrieren</h1>
                        <p>
							<form action="#" method="post">
								<table>
									<tr>
										<td>E-Mail </td>
										<td><input type="email" name="email" /></td>
									</tr>
									<tr>
										<td>Passwort </td>
										<td><input type="password" name="pwd1" /></td>
									</tr>
									<tr>
										<td>Passwort wiederholen</td>
										<td><input type="password" name="pwd2" /></td>
									</tr>
									<tr>
										<td></td>
										<td><input type="submit" value="Einloggen" /></td>
									</tr>
								</table>
							</form>
							<?php
								if(!empty($_POST["email"]) && !empty($_POST["pwd1"]) && !empty($_POST["pwd2"])) {
									$email = htmlspecialchars(stripcslashes(trim($_POST["email"])));
									$pwd1  = htmlspecialchars(stripcslashes(trim($_POST["pwd1"] )));
									$pwd2  = htmlspecialchars(stripcslashes(trim($_POST["pwd2"] )));
									
									if($pwd1 != $pwd2) {
										echo "Die beiden Passwörter sind nicht gleich";
									} else {
										include "user/config.php";
										
										$hashed = hash("sha512", $pwd1);
										
										$conn = new mysqli($s_name, $s_username, $s_password, $s_dbname);
					
										if($conn->connect_error) {
										   die("Es gab ein Problem mit der Datenbankverbindung. Bitte versuche es später erneut.");
										}
										$sql = $conn->prepare("INSERT INTO users (email, password) VALUES (?,?)");
										$sql->bind_param("ss", $email, $hashed);
										$sql->execute();
										$sql->close();
										
										echo "Du wurdest erfolgreich registriert";
									}
								}
							?>
						</p>
                    </header>
                </article>

            </div> <!-- #main -->
        </div> <!-- #main-container -->

        <div class="footer-container">
            <footer class="wrapper">
                <h3>Ein Projekt von PiDi, Spike und Julius im Rahmen des Scoutlabs 2018</h3>
            </footer>
        </div>

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.js"><\/script>')</script>

        <script src="js/main.js"></script>
    </body>
</html>
