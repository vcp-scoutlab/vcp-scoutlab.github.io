<?php
	include "user/config.php";
	
	$timestamp = date("U");
	
	echo (30-($timestamp%30))+$timestamp;
	
	if(!empty($_GET["plus"]) && !empty($_GET["mitte"]) && !empty($_GET["minus"]) && !empty($_GET["avr"]) && !empty($_GET["hash"])) {
		$plus = htmlspecialchars(stripcslashes(trim($_GET["plus"])));
		$mittel = htmlspecialchars(stripcslashes(trim($_GET["mitte"])));
		$schlecht = htmlspecialchars(stripcslashes(trim($_GET["minus"])));
		$avr = htmlspecialchars(stripcslashes(trim($_GET["avr"])));
		$hash = htmlspecialchars(stripcslashes(trim($_GET["hash"])));
		
		$time1 = (30-($timestamp%30))+$timestamp;
		$time2 = $time1 - 30;
		$time3 = $time2 - 30;
		
		file_put_contents("debug.txt","#" . $recv_pwd . $time1 . ";" . $plus . ";" . $mittel . ";" . $schlecht . ";" . $avr . "#\n");
		
		$hash1 = md5($recv_pwd . $time1 . ";" . $plus . ";" . $mittel . ";" . $schlecht . ";" . $avr);
		$hash2 = md5($recv_pwd . $time2 . ";" . $plus . ";" . $mittel . ";" . $schlecht . ";" . $avr);
		$hash3 = md5($recv_pwd . $time3 . ";" . $plus . ";" . $mittel . ";" . $schlecht . ";" . $avr);
		
		if(($hash == $hash1) || ($hash == $hash2) || ($hash == $hash3)) {
			$conn = new mysqli($s_name, $s_username, $s_password, $s_dbname);
							
			if($conn->connect_error) {
				die("Es gab ein Problem mit der Datenbankverbindung. Bitte versuche es später erneut.");
			}
			$sql = $conn->prepare("SELECT ID FROM stimmungsboard WHERE hash=?");
			$sql->bind_param("s", $hash);
			$sql->execute();
			$sql->bind_result($res_ID);
			if($sql->fetch() == 0) {
				echo "Hey";
				$datum = date("d.m.Y");

				$conn = new mysqli($s_name, $s_username, $s_password, $s_dbname);
								
				if($conn->connect_error) {
					die("Es gab ein Problem mit der Datenbankverbindung. Bitte versuche es später erneut.");
				}
				$sql = $conn->prepare("INSERT INTO stimmungsboard (Datum, Gut, Mittel, Schlecht, Schnitt,hash) VALUES (?,?,?,?,?,?)");
				$sql->bind_param("siiids", $datum, $plus, $mittel, $schlecht,$avr,$hash);
				$sql->execute();
			}
		}
	}
?>