        <div class="footer-container">
            <footer class="wrapper">
                <h3>Ein Projekt von PiDi, Spike und Julius im Rahmen des Scoutlabs 2018</h3>
            </footer>
        </div>

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.js"><\/script>')</script>

        <script src="js/main.js"></script>
    </body>
</html>