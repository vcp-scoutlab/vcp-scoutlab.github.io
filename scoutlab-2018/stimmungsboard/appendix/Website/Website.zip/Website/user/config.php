<?php
	$s_name = "127.0.0.1";
	$s_username = "root";
	$s_password = "";
	$s_dbname = "stimmungsboard";
	
	$recv_pwd = "1234";
	
	function inputsaver($input) {
		  $saver = htmlspecialchars(stripcslashes(trim($input)));
		
		  return $saver;
	  }
     
    function genHash($input) {
		  $hashed = hash("sha512", $input);
		  return $hashed;
	  }
    
    function checklogin($filepath) {
        if ($_SESSION["login"] == False) {
          header("location:" .  $filepath);
        }
    }
?>